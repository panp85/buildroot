# This package contains code using async iteratino added in Python 3.6.
# It cannot be imported on Python < 3.6 because it triggers syntax errors.
