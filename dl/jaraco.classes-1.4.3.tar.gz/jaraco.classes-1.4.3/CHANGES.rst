1.4.3
=====

Corrected namespace package declaration to match
``jaraco`` namespaced packages.

1.4.2
=====

#1: Added a project description.

1.4.1
=====

Refresh packaging.

1.4
===

Added documentation.

Project is now automatically released by Travis CI.

1.3
===

Move hosting to Github.

Use setuptools_scm for version detection.

1.2
===

Limit dependencies in setup_requires.

1.1
===

Added ``properties`` module from jaraco.util 10.8.

1.0
===

Initial release based on jaraco.util 10.8.
