Welcome to jaraco.classes documentation!
========================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: jaraco.classes.ancestry
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: jaraco.classes.meta
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: jaraco.classes.properties
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

