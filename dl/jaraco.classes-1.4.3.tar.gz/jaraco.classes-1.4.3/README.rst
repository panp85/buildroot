.. image:: https://img.shields.io/pypi/v/jaraco.classes.svg
   :target: https://pypi.org/project/jaraco.classes

.. image:: https://img.shields.io/pypi/pyversions/jaraco.classes.svg

.. image:: https://img.shields.io/travis/jaraco/jaraco.classes/master.svg
   :target: http://travis-ci.org/jaraco/jaraco.classes

.. image:: https://readthedocs.org/projects/skeleton/badge/?version=latest
   :target: http://skeleton.readthedocs.io/en/latest/?badge=latest
