Contact
-------

For historical and practical reasons, Mutagen shares a `mailing list
<http://groups.google.com/group/quod-libet-development/>`_ and IRC channel
(#quodlibet on irc.oftc.net) with Quod Libet.

If you need help using Mutagen or would like to discuss the library, please
use the IRC channel, our `issue tracker
<https://github.com/quodlibet/mutagen/issues>`_ or the mailing list.
