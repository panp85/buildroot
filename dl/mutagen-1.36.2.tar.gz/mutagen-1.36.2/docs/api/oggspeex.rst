Ogg Speex
=========

.. automodule:: mutagen.oggspeex

.. autoclass:: mutagen.oggspeex.OggSpeex
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggspeex.OggSpeexInfo
    :show-inheritance:
    :members:
