OGG
===

.. automodule:: mutagen.ogg

.. autoclass:: mutagen.ogg.OggFileType
    :show-inheritance:
    :members:
