Ogg Vorbis
----------

.. automodule:: mutagen.oggvorbis

.. autoclass:: mutagen.oggvorbis.OggVorbis
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggvorbis.OggVorbisInfo
    :show-inheritance:
    :members:
