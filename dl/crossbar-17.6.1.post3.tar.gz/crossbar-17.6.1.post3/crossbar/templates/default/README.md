Generated from Crossbar.io default node template.
