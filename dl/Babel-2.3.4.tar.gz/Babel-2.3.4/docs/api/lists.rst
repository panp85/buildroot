List Formatting
===============

.. module:: babel.lists

This module lets you format lists of items in a locale-dependent manner.

.. autofunction:: format_list
