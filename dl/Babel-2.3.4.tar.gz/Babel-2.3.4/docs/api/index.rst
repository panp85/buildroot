API Reference
=============

This part of the documentation contains the full API reference of the
public API of Babel.

.. toctree::
   :maxdepth: 2

   core
   dates
   languages
   lists
   messages/index
   numbers
   plural
   support
   units
