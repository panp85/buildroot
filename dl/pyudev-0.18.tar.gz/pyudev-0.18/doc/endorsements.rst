pyudev Users
============

If you are using pyudev and would like the world to know how and why, here is
the place. Just submit a PR with an addition to the documentation, something
like:

--------------------------------------------------------------------------------
Choice of information about yourself.
--------------------------------------------------------------------------------
What you are doing with pyudev and why it beats the alternatives.
