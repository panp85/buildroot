API documentation
=================

This document provides API reference documentation for pyudev.  Refer to the
:doc:`../guide` for an introduction into pyudev.

.. autosummary::
   :toctree: .

   pyudev
   pyudev.pyqt4
   pyudev.pyqt5
   pyudev.pyside
   pyudev.glib
   pyudev.wx
