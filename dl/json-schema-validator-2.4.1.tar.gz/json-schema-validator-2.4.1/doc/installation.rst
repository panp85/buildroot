Installation
============

Prerequisites
^^^^^^^^^^^^^

This package has the following prerequisites:

* versiontools

To run the test suite you will also need:

* testtools
* testscenarios

To build the documentation from source you will also need:

* sphinx

Installation Options
^^^^^^^^^^^^^^^^^^^^

This package is being actively maintained and published in the `Python Package
Index <http://http://pypi.python.org>`_. You can install it if you have `pip
<http://pip.openplans.org/>`_ tool using just one line::

    pip install json-schema-validator
