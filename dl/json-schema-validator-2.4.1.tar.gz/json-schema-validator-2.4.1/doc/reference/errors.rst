Errors module
^^^^^^^^^^^^^

.. automodule:: json_schema_validator.errors
    :members:
