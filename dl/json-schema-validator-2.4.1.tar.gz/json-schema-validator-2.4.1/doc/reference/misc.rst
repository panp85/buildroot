Misc module
^^^^^^^^^^^

.. automodule:: json_schema_validator.misc
    :members:
