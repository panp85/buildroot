Shortcuts module
^^^^^^^^^^^^^^^^

.. automodule:: json_schema_validator.shortcuts
    :members:
