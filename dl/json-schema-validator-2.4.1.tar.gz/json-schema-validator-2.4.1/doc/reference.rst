Code documentation
******************

.. automodule:: json_schema_validator

.. toctree::
    :maxdepth: 2
    
    reference/errors.rst
    reference/misc.rst
    reference/schema.rst
    reference/shortcuts.rst
    reference/validator.rst
