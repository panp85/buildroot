"pylibftdi examples"
