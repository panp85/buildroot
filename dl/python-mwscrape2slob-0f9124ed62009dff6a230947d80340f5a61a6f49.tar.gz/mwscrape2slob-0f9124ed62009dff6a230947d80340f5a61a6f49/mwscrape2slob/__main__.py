from mwscrape2slob import main
if __name__ == '__main__':
    main()
