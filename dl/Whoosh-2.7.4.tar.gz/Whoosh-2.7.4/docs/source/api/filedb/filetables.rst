============================
``filedb.filetables`` module
============================

.. automodule:: whoosh.filedb.filetables


Hash file
=========

.. autoclass:: HashWriter
    :members:

.. autoclass:: HashReader
    :members:


Ordered Hash file
=================

.. autoclass:: OrderedHashWriter
.. autoclass:: OrderedHashReader
