Mako is a templating language. I have some unfinished work here
to attempt to get markdown2.py to treat Mako syntax just like raw
HTML. I.e. allow writing mixed Markdown-Mako text.

The key here is *unfinished*. I'm not sure if it is reasonable or feasible
to support this with the current implementation.
