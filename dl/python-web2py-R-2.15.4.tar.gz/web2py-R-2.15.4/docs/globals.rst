
:mod:`globals` Module
---------------------

.. automodule:: gluon.globals
    :members:
    :undoc-members:
    :show-inheritance:
