
:mod:`settings` Module
----------------------

.. automodule:: gluon.settings
    :members:
    :undoc-members:
    :show-inheritance:
