
:mod:`highlight` Module
-----------------------

.. automodule:: gluon.highlight
    :members:
    :undoc-members:
    :show-inheritance:
