
:mod:`shell` Module
--------------------

.. automodule:: gluon.shell
    :members:
    :undoc-members:
    :show-inheritance:
