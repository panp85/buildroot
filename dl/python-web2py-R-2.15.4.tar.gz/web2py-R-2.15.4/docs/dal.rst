
:mod:`dal` Module
-------------------

Go to http://pydal.readthedocs.org/en/latest/ for docs on pyDAL

.. automodule:: gluon.dal
    :members:
    :undoc-members:
    :show-inheritance:
