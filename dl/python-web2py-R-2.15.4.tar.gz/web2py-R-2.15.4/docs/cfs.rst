
:mod:`cfs` Module
-----------------

.. automodule:: gluon.cfs
    :members:
    :undoc-members:
    :show-inheritance:
