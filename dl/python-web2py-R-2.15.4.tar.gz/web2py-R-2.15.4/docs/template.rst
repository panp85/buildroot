
:mod:`template` Module
----------------------

.. automodule:: gluon.template
    :members:
    :undoc-members:
    :show-inheritance:
