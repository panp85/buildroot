
:mod:`xmlrpc` Module
--------------------

.. automodule:: gluon.xmlrpc
    :members:
    :undoc-members:
    :show-inheritance:

