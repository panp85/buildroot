(function(App) {
    'use strict';
    
    $(document).ready(function($) {
    	App.ready($);
    });

})(window.App);


