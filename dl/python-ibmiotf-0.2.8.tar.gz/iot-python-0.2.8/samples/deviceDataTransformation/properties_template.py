orgid = "xxxxx"
key = "a-xxxxx-xxxxxxxxxx"
token = "xxxxxxxxxxxxxxxxxx"
devicetype = "iotsample-mbed-k64f"
deviceid = "xxxxxxxxxxxx"

