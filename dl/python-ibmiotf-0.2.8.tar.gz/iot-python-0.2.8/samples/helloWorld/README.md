#Hello World Sample
Sample code demonstrating how to send events to the cloud from a device and process them in an application.


##Usage

```
me@localhost ~ $ python helloworld.py
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:27: hello=world x=0
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:28: hello=world x=1
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:29: hello=world x=2
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:30: hello=world x=3
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:31: hello=world x=4
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:32: hello=world x=5
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:33: hello=world x=6
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:34: hello=world x=7
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:35: hello=world x=8
Received live data from ca72af10ef14 (helloWorldDevice) sent at 19:33:36: hello=world x=9
```

