#!/bin/sh

python tests/decoding_test.py
