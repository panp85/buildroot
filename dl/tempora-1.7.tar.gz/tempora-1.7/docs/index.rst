Welcome to tempora documentation!
=================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: tempora
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: tempora.timing
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: tempora.schedule
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

