# coding: utf-8
import unittest

from tomako.tests.mako_loader_test import *
from tomako.tests.uimodule_test import *


unittest.main()
