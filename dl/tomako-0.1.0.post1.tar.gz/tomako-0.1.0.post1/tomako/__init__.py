# coding: utf-8
from tomako.loader import MakoTemplateLoader
