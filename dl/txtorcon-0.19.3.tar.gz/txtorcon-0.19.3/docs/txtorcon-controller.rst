High Level API
==============

This is the recommended API. See the :ref:`programming_guide` for
"prose" documentation of these (and other) APIs.


Tor
----
.. autoclass:: txtorcon.Tor


connect
-------

# FIXME why doesn't "txtorcon.connect" work here with automethod??

.. method:: txtorcon.connect


launch
------

.. method:: txtorcon.launch
