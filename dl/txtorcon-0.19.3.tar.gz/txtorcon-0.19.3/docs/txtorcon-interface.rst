:mod:`txtorcon.interface` Module
================================

interface.IStreamAttacher
-------------------------
.. autointerface:: txtorcon.interface.IStreamAttacher

interface.IStreamListener
-------------------------
.. autointerface:: txtorcon.interface.IStreamListener

interface.ICircuitListener
--------------------------
.. autointerface:: txtorcon.interface.ICircuitListener

interface.ICircuitContainer
---------------------------
.. autointerface:: txtorcon.interface.ICircuitContainer

interface.IRouterContainer
--------------------------
.. autointerface:: txtorcon.interface.IRouterContainer

interface.ITorControlProtocol
-----------------------------
.. autointerface:: txtorcon.interface.ITorControlProtocol
