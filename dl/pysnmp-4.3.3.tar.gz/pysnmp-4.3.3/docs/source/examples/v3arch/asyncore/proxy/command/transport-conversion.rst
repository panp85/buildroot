.. toctree::
   :maxdepth: 2

Transport conversion
--------------------

.. include:: /../../examples/v3arch/asyncore/proxy/command/udp6-to-udp4-conversion.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v3arch/asyncore/proxy/command/udp6-to-udp4-conversion.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v3arch/asyncore/proxy/command/udp6-to-udp4-conversion.py>` script.


See also: :doc:`library-reference </docs/api-reference>`.
