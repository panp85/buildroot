
PySNMP command-line tools
-------------------------

Here is a set of SNMP applications written on top of the PySNMP package
(http://sourceforge.net/projects/pysnmp/). Some of these tools mimic
their famous Net-SNMP (http://sourceforge.net/projects/net-snmp/)
counterparts, while others are designed toward easy integration with
other Python applications.

PySNMP command-line tools are written entirely in Python and only rely 
upon PySNMP package to run (PySNMP requires other Python packages). For
MIB resolution services to work for popular MIBs, pysnmp-mibs package
should be installed as well.

These tools have been tested on Linux & Windows XP, though, they might work
on any Python-populated system.

The whole package is distributed under terms and conditions of BSD-style 
license. See the LICENSE file for details.

INSTALLATION
------------

The pysnmp-apps package is fully distutil'ed, so just type

$ python setup.py install

to install the whole thing.

PySNMP version 4.3.x or later is required to run these tools.

OPERATION
---------

The most of PySNMP command-line tools could be run in a similar way as 
their Net-SNMP counterparts. For example:

$ snmpbulkwalk.py -v3 -u myuser -l authPriv -A myauthkey -X myprivkey localhost system
SNMPv2-MIB::sysDescr.0 = DisplayString: Linux grommit 2.6.16.1 #2 PREEMPT Tue Apr 4 17:04:24 MSD 2006 i686 unknown unknown GNU/Linux
SNMPv2-MIB::sysObjectID.0 = ObjectIdentifier: iso.org.dod.internet.private.enterprises.8072.3.2.101.3.6.1.4.1.8072.3.2.10
SNMPv2-MIB::sysUpTime.0 = TimeTicks: 43 days 1:55:47.85372214785
[ skipped ]
SNMPv2-MIB::sysORUpTime."8" = TimeStamp: 0 days 0:0:0.77
SNMPv2-MIB::sysORUpTime."9" = TimeStamp: 0 days 0:0:0.77

$ snmpget.py -v3 -u myuser -l authPriv -A myauthkey -X myprivkey localhost IP-MIB::ipAdEntBcastAddr.\"127.0.0.1\"
IP-MIB::ipAdEntBcastAddr."127.0.0.1" = Integer32: 1

$ snmpset.py -v2c -c public localhost SNMPv2-MIB::sysDescr.0 = my-new-descr
notWritable(17)

To enjoy MIB resolution features make sure to have PySMI MIB Compiler 
(http://sf.net/projects/pysmi) installed on your system.

For more information, please, run any of these tools with --help option.

GETTING HELP
------------

Try PySNMP mailing list at http://sourceforge.net/mail/?group_id=14735

=-=-=
mailto: ilya@glas.net
