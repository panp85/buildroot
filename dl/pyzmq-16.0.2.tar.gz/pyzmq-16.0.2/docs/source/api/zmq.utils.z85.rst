.. AUTO-GENERATED FILE -- DO NOT EDIT!

utils.z85
=========

Module: :mod:`utils.z85`
------------------------
.. automodule:: zmq.utils.z85

.. currentmodule:: zmq.utils.z85

Functions
---------


.. autofunction:: zmq.utils.z85.decode


.. autofunction:: zmq.utils.z85.encode

