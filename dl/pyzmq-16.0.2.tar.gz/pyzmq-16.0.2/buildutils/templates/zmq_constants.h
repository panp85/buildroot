#ifndef _PYZMQ_CONSTANT_DEFS
#define _PYZMQ_CONSTANT_DEFS

#ifdef ZMQ_BUILD_DRAFT_API
    #define PYZMQ_DRAFT_API 1
#else
    #define PYZMQ_DRAFT_API 0
#endif

{ZMQ_IFNDEFS}


#endif // ifndef _PYZMQ_CONSTANT_DEFS
