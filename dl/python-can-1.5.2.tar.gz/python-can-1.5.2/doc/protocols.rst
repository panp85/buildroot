Protocols
=========

The :mod:`~can.protocols.j1939` protocol is the only CAN protocol that is currently
implemented.

.. warning::

   Protocols are being removed in the next major release.

