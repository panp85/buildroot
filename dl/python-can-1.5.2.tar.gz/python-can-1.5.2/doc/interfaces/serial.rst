.. _serial:

CAN over Serial
===============

A text based interface. For example use over bluetooth with
``/dev/rfcomm0``

Bus
---

.. autoclass:: can.interfaces.serial.serial_can.SerialBus

Internals
---------

.. TODO:: Implement and document serial interface.
