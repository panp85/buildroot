"""
A protocol redefines Bus and Message.
"""

import warnings
warnings.warn("protocols are going to be removed from python-can", DeprecationWarning)
