
import time
time.sleep(1)

print """factor: 1
factor: 1000003
factor: 2000029
factor: 3000073
factor: 4000159
factor: 5000101"""
