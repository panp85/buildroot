Authors
=======

**see** is written and maintained by Liam Cooke, with features, patches, and
suggestions from various contributors:

- `Liam Cooke <https://github.com/ljcooke>`__
- Ian Gowen
- `Baishampayan Ghose <https://github.com/ghoseb>`__
- `Jeremy Dunck <https://github.com/jdunck>`__
- Gabriel Genellina
- `Eduardo de Oliveira Padoan <https://github.com/edcrypt>`__
- `Guff <https://github.com/Guff>`__
- `Bob Farrell <https://github.com/bobf>`__
- `Ed Page <https://github.com/epage>`__
- Charlie Nolan
- `Steve Losh <https://github.com/sjl>`__
- `Adam Lloyd <https://github.com/alloy-d>`__
- `Andrei Fokau <https://github.com/andreif>`__
- `Christopher Toth <https://github.com/ctoth>`__
- `Elias Fotinis <https://github.com/efotinis>`__
- `Frederic De Groef <https://github.com/sevas>`__
- `hugovk <https://github.com/hugovk>`__
- `dbaker <https://github.com/d-baker>`__
